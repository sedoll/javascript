export default interface ILoginFormValue {
  username: string;
}