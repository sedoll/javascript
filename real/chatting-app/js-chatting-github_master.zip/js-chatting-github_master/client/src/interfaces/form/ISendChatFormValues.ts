export default interface ISendChatFormValues {
  content: string;
}