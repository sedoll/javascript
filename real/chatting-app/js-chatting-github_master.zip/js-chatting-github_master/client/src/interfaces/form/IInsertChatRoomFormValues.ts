export default interface IInsertChatRoomFormValues {
  title: string;
}