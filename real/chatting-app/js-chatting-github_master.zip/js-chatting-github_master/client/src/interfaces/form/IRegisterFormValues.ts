export default interface IRegisterFormValues {
  username: string;
  name: string;
}