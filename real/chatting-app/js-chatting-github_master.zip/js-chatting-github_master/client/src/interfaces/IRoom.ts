export default interface IRoom {
  id:number;
  title:string;
  createTime: string;
  userNum: number;
}